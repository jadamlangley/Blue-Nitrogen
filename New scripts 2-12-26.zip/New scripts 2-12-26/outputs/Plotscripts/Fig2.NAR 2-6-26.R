# 1. & 2. DATA PROCESSING (Keep your existing code here)

# 3. PANEL A: Font size +1 (assuming baseline 11, we'll go to 12)
NAR_histogram <- ggplot(df2, aes(y = NAR, fill = Vegetation)) +
  geom_histogram(binwidth = .08, color = "white") +
  scale_y_log10() + 
  labs(x = "Observations", 
       y = expression("N accumulation rate (g N " ~ m^{-2} ~ yr^{-1} ~ ")")) +
  theme_minimal(base_size = 12) + # Increases base font size everywhere
  theme(panel.grid = element_blank(),
        axis.line = element_line(linewidth = 0.2),
        legend.position = "none",
        axis.title.y = element_text(margin = margin(t = -15), size = 13), # Manual bump
        axis.title.x = element_text(margin = margin(t = -35), size = 13), # Manual bump
        plot.margin = margin(t = 10, r = 0, b = 10, l = 10))

# 4. PANEL B: Capitalized labels and increased font
stacked_plot <- ggplot() +
  geom_bar(data = marshmangrove, aes(x = Region, y = predicted_N, fill = Habitat),
           stat = "identity", position = "stack", width = .6) +
  geom_errorbar(data = total, 
                aes(x = Region, ymin = predicted_N - predicted_N_se, ymax = predicted_N + predicted_N_se),
                width = 0.2) +
  # Use labels to capitalize Marsh and Mangrove in the legend
  scale_fill_discrete(labels = c("mangrove" = "Mangrove", "marsh" = "Marsh")) +
  labs(x = NULL, 
       y = expression("Scaled N accumulation (Gg N " ~ yr^{-1} ~ ")")) +
  theme_minimal(base_size = 12) + 
  theme(panel.grid = element_blank(),
        axis.line.y = element_line(linewidth = 0.2),
        axis.text.x = element_text(angle = 90, vjust = 0.5, hjust = 1),
        legend.position = c(0.7, 0.85), 
        legend.background = element_blank(),
        legend.title = element_blank(),
        legend.text = element_text(size = 11),
        plot.margin = margin(t = 10, r = 10, b = 0, l = -10),
        aspect.ratio = 3)

# 5. COMBINE AND SAVE
# The '&' operator in patchwork applies changes to ALL panels at once
fig2 <- (NAR_histogram + stacked_plot) + 
  plot_layout(widths = c(1, 1)) & 
  theme(text = element_text(size = 12), # Forces +1 pt bump across all text
        plot.margin = margin(5, 5, 5, 5))

print(fig2)
ggsave("outputs/2.NAR_refined.pdf", plot = fig2, width = 8, height = 5)