#install.packages("ggnewscale")
# install.packages(c("dplyr", "ggplot2", "RColorBrewer", "patchwork", "scales", "metR", "ggrepel", "ggnewscale"))
# 1. LOAD LIBRARIES
# ---------------------------------------------------------
# install.packages(c("dplyr", "ggplot2", "RColorBrewer", "patchwork", "scales", "metR", "ggrepel", "ggnewscale"))
library(dplyr)
library(ggplot2)
library(RColorBrewer)
library(patchwork)
library(scales)
library(ggrepel)
library(metR)
library(ggnewscale)

# 2. PARAMETERS & HISTORICAL DATA (1970-2019)
# ---------------------------------------------------------
if (!dir.exists("outputs")) dir.create("outputs")
Ndensitymarsh <- 1.946
Ndensitymangrove <- 1.939

historical <- data.frame(
  scenario = 0, scenarioname = "Historical",
  year = 1970:2019,
  rSLR = seq(2.1, 3.5, length.out = 50)
) %>%
  mutate(
    Amarsh = 52879.948 + (106183 - 52879.948) * exp(-exp(-(-0.063154) * (year - 1977.3934))),
    Amangrove = 147353.96 + (295896.02 - 147353.96) * exp(-exp(-(-0.057107) * (year - 1978.1772))),
    Atotal = Amarsh + Amangrove,
    SL = cumsum(rSLR) - 140,
    Ngaintotal = ((Amarsh * (SL/10) * (Ndensitymarsh/1000)) + (Amangrove * (SL/10) * (Ndensitymangrove/1000))) * 10^10 / 10^12,
    Nlosstotal = (ifelse(Amarsh > 52880, (Amarsh - 52880) * 30 * (Ndensitymarsh/1000), 0) + 
                    ifelse(Amangrove > 147349, (Amangrove - 147349) * 30 * (Ndensitymangrove/1000), 0)) * 10^10 / 10^12,
    netNtotal = Ngaintotal + Nlosstotal
  )

# 3. FUTURE SCENARIOS (2020-2100)
# ---------------------------------------------------------
scenarios <- data.frame(
  scenario = rep(1:6, each = 81),
  scenarioname = rep(c('Area loss/low slr', 'Area loss/high slr', 'Area stable/low slr', 
                       'Area stable/high slr', 'Area gain/low slr', 'Area gain/high slr'), each = 81),
  R2020 = 3.5, R2100 = rep(c(4, 8, 4, 8, 4, 8), each = 81),
  year = rep(2020:2100, times = 6)
) %>%
  mutate(
    k = log(R2100 / R2020) / 80,
    rSLR = R2020 * exp(k * (year - 2020)),
    A2100msh = case_when(scenario %in% 1:2 ~ 52880-20623, scenario %in% 3:4 ~ 52880-1568, TRUE ~ 52880+20905),
    A2100mng = case_when(scenario %in% 1:2 ~ 147349-144412, scenario %in% 3:4 ~ 147349-4421, TRUE ~ 147349+99434),
    Amarsh = 52880 + (1/(1+exp((2060-year)/8)))*(A2100msh-52880),
    Amangrove = 147349 + (1/(1+exp((2060-year)/8)))*(A2100mng-147349),
    Atotal = Amarsh + Amangrove
  ) %>%
  group_by(scenario) %>%
  mutate(SL = cumsum(rSLR),
         Ngaintotal = ((Amarsh * (SL/10) * (Ndensitymarsh/1000)) + (Amangrove * (SL/10) * (Ndensitymangrove/1000))) * 10^10 / 10^12,
         Nlosstotal = (ifelse(Amarsh < 52880, (Amarsh - 52880) * 50 * (Ndensitymarsh/1000), 0) + 
                         ifelse(Amangrove < 147349, (Amangrove - 147349) * 50 * (Ndensitymangrove/1000), 0)) * 10^10 / 10^12,
         netNtotal = Ngaintotal + Nlosstotal) %>%
  ungroup()

# Set factor levels for consistent coloring
scen_lvls <- c('Area gain/low slr', 'Area gain/high slr', 'Area loss/low slr', 
               'Area loss/high slr', 'Area stable/low slr', 'Area stable/high slr', 'Historical')
line_colors <- c("turquoise3", "turquoise3", "indianred", "indianred", "darkorange", "darkorange", "black")
line_types <- c("dashed", "solid", "dashed", "solid", "dashed", "solid", "dotted")

combined_data <- bind_rows(historical, scenarios) %>%
  mutate(scenarioname = factor(scenarioname, levels = scen_lvls))

# 4. CONTOUR GRID GENERATION
# ---------------------------------------------------------
contour_grid <- expand.grid(SL = seq(-140, 500, by = 5), Amarsh = seq(5000, 90000, by = 1000)) %>%
  mutate(Amangrove = Amarsh * 2.786, Atotal = Amarsh + Amangrove,
         Ngaintotal = ((Amarsh * (SL/10) * (Ndensitymarsh/1000)) + (Amangrove * (SL/10) * (Ndensitymangrove/1000))) * 10^10 / 10^12,
         Nlosstotal = (ifelse(Amarsh < 52880, (Amarsh-52880)*50*(Ndensitymarsh/1000), 0) + 
                         ifelse(Amangrove < 147349, (Amangrove-147349)*50*(Ndensitymangrove/1000), 0)) * 10^10 / 10^12,
         netNtotal = Ngaintotal + Nlosstotal)

# 5. GENERATE SUBPLOTS
# ---------------------------------------------------------

# Define labels and colors for specific points
point_colors <- c(
  "Area gain/low slr" = "turquoise3", "Area gain/high slr" = "turquoise3", 
  "Area loss/low slr" = "indianred", "Area loss/high slr" = "indianred", 
  "Area stable/low slr" = "darkorange", "Area stable/high slr" = "darkorange",
  "Modern" = "black", "1970" = "white"
)

plot_points <- combined_data %>% 
  filter((year %in% c(1970, 2019) & scenario == 0) | year == 2100) %>%
  mutate(point_label = case_when(
    year == 1970 ~ "1970",
    year == 2019 ~ "Modern",
    TRUE ~ as.character(scenarioname)
  ))

# Calculate center for color shift (aligning lightest color to 0 Net N)
min_N <- min(contour_grid$netNtotal, na.rm = TRUE)
max_N <- max(contour_grid$netNtotal, na.rm = TRUE)
zero_pos <- rescale(0, from = c(min_N, max_N))

# MAIN PLOT (A)
p_main <- ggplot() +
  # Continuous Contour Layer
  geom_raster(data = contour_grid, aes(x = Atotal, y = SL, fill = netNtotal), interpolate = TRUE) + 
  geom_contour(data = contour_grid, aes(x = Atotal, y = SL, z = netNtotal), 
               breaks = seq(-200, 400, by = 50), color = "black", alpha = 0.3) +
  metR::geom_text_contour(data = contour_grid, aes(x = Atotal, y = SL, z = netNtotal), 
                          breaks = seq(-200, 400, by = 50), stroke = 0, size = 3, color = "black") +
  scale_fill_gradientn(colors = brewer.pal(11, "Spectral"), 
                       name = "Net N (Tg)", 
                       values = c(0, zero_pos, 1)) +
  
  # Discrete Point Layer
  new_scale_fill() + 
  geom_point(data = plot_points, aes(x = Atotal, y = SL, fill = point_label), 
             color = "black", size = 3, shape = 21, stroke = 1.) +
  scale_fill_manual(values = point_colors, name = "Scenario/Point") +
  
  # Labels
  #geom_text_repel(data = plot_points, aes(x = Atotal, y = SL, label = point_label),
   #               size = 3.2, fontface = "bold", box.padding = 0.8, point.padding = 0.5,
    #              bg.color = "white", bg.r = 0.15) +
  
  scale_x_continuous(labels = comma, expand = c(0.02, 0)) + 
  scale_y_continuous(expand = c(0.02, 0)) +
  labs(x = expression("Total Area " (km^2)), y = "Cumulative elevation gain (mm)") +
  theme_minimal() + theme(panel.grid = element_blank(), axis.line = element_line(color = "black"), legend.position = "bottom")

# TIME SERIES PLOTS (B)
ts_theme <- theme_minimal() + theme(legend.position = "none", axis.title = element_blank(), panel.grid = element_blank(), axis.line = element_line(color = "gray50"), plot.title = element_blank())

p1 <- ggplot(combined_data, aes(x = year, y = netNtotal, color = scenarioname, linetype = scenarioname)) +
  geom_line() + scale_color_manual(values = line_colors) + scale_linetype_manual(values = line_types) +
  labs(title = "Net N gain (Tg)") + ts_theme + scale_x_continuous(limits = c(2000, 2100))

p2 <- ggplot(combined_data, aes(x = year, y = Ngaintotal, color = scenarioname, linetype = scenarioname)) +
  geom_line() + scale_color_manual(values = line_colors) + scale_linetype_manual(values = line_types) +
  labs(title = "Gross N gain (Tg)") + ts_theme + scale_x_continuous(limits = c(2000, 2100))

p3 <- ggplot(combined_data, aes(x = year, y = Nlosstotal, color = scenarioname, linetype = scenarioname)) +
  geom_line() + scale_color_manual(values = line_colors) + scale_linetype_manual(values = line_types) +
  labs(title = "Gross N Loss (Tg)") + ts_theme + scale_x_continuous(limits = c(2000, 2100))

# 6. ASSEMBLE & SAVE
# ---------------------------------------------------------
fig_final <- (p_main | (p1 / p2 / p3)) + plot_layout(widths = c(2, 1))
print(fig_final)
ggsave("outputs/Composite_N_Analysis.pdf", fig_final, width = 12, height = 8)